# CS189/289A Neural Networks Homework

Before running the code in this directory, please create a new `conda`
environment by running:
```sh
bash conda_create.sh
conda activate cs189
```