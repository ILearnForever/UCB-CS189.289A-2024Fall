conda create --name cs189 python=3.8 numpy matplotlib scikit-learn tqdm pandas jupyter
